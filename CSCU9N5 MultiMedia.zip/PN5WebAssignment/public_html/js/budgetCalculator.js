function calculateBudget() {
    //taks values from the form located in budget calculator page and sets them in local variables
    var cpuListValue = document.getElementById("cpuList").value;
    var motherboardListValue = document.getElementById("motherboardList").value;
    var RAMListValueValue = document.getElementById("RAMList").value;
    var powerSupplyListValue = document.getElementById("PowerSupplyList").value;
    var graphicsCardListValue = document.getElementById("GraphicsCardList").value;
    var hardDriveListValue = document.getElementById("HarddriveList").value;
    //adding all the values togther
    var x = +cpuListValue + +motherboardListValue + +RAMListValueValue + +powerSupplyListValue + +graphicsCardListValue + +hardDriveListValue;
    //setting the ans tag to the value of x
    document.getElementById("ans").innerHTML = "£" +x;
}