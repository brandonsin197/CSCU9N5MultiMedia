
/* Toggle between adding and removing the "responsive" class to the requested 
 element when the user clicks on the icon.
 
 @param elemId the ID of the element to modify.
 */
function toggleClass(menuId, iconId)
{
    //getting the menu element
    var menuElem = document.getElementById(menuId);
    //adding the reposnive design by setting class name so the css uses it
    if (menuElem != null) {
        if (menuElem.className === "topnav") {
            menuElem.className += " responsive";
        }
        else {
            menuElem.className = "topnav";
        }
    }
}