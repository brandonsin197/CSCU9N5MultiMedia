//Refrence: java script taken from lab practical. 
var inum = 1;
var floop = 0;

//code the button functionalty and setting the images

function newSlide(inum)
{
    var iname = "img/cpu" + inum + ".jpg";
    var newimg = document.getElementById("slide");
    newimg.setAttribute("src", iname);
    var slidenum = "Slide " + inum + " of 3";
    document.getElementById("slnum").innerHTML = slidenum;
}

function nextSlide()
{
    inum = inum + 1;
    newSlide(inum);
    document.getElementById("btnSlPrev").disabled = false;
    if (inum == 3) {
        document.getElementById("btnSlNxt").disabled = true;
    }
}

function prevSlide()
{
    inum = inum - 1;
    newSlide(inum);
    document.getElementById("btnSlNxt").disabled = false;
    if (inum == 1) {
        document.getElementById("btnSlPrev").disabled = true;
    }
}

function loopSlide()
{
    inum = inum + 1;
    if (inum > 3) {
        inum = 1;
    }
    newSlide(inum);

    if (floop == 1) {
        setTimeout(loopSlide, 1000);
    }
}

function runLoop()
{
    if (floop == 0) {
        floop = 1;
        loopSlide();
    } else {
        floop = 0;
    }
}


